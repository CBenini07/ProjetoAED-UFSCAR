# ProjetoAED-UFSCAR
Projeto em grupo realizado pelos alunos Vinicius Faria, Maurício de Almeida e Cauã Benini, alunos de Engenharia da Computação na Universidade Federal de São Carlos (UFSCAR) em 2022.
