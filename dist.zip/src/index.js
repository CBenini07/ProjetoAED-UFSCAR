import { DOM } from "./modulos/DOM";

DOM.init();